package com.springboot.app.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.app.dao.RegisterRepository;
import com.springboot.app.model.Register;

@CrossOrigin(origins="http://localhost:4200")

@RestController
@RequestMapping("/da")

public class RegisterController {

		
		@Autowired
	    private RegisterRepository repo;
	
		
		
		@PostMapping("/add")
	    public String add(@RequestBody Register register) {
	        repo.save(register);
	        return "Hi, your Registration process successfully completed";
	        
	    }
		 @PostMapping("/forms")
			public Register doRegister( @RequestBody Register register) {
				return repo.save(register);
			}
		 
		 
		 @PostMapping("/login")
		    public  boolean login(@RequestBody Register register) throws ResourceNotFoundException {
			 System.out.println(register.getUsername());
			 Register res=repo.findById(register.getUsername()).orElseThrow(() -> new ResourceNotFoundException());
			 System.out.println(res);
			 if(!res.equals(null))
			 {
				 //return true;
				 System.out.println("Successfully login");
				 
				 System.out.println(res.getUsername().length()+"  "+res.getPassword().length());
					System.out.println(register.getUsername().length()+"  "+register.getPassword().length());
				 
				 return true;

				 
			 }
				 return false;
		        
		    }
	}


