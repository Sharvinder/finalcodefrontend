package com.springboot.app.controller;

public class ResourceNotFoundException extends Exception {

}
